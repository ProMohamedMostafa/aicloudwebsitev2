"use client";

import { useRef, useLayoutEffect, useState } from "react";
import "./cleanTechContact.css";
import gsap from "gsap";
import { BASE_URL } from "@/config/api";

export default function CleanTechContact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });
  const [errors, setErrors] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<{
    type: "success" | "error" | null;
    message: string;
  }>({ type: null, message: "" });

  // Honeypot field — bots fill this in, humans never see it (visually hidden)
  const [honeypot, setHoneypot] = useState("");

  // Track form render timestamp to detect instant bot submissions
  const formRenderedAt = useRef<number>(Date.now());

  // Refs for animations
  const sectionRef = useRef(null);
  const heroRef = useRef(null);
  const formRef = useRef(null);
  const titleRef = useRef(null);
  const descriptionRef = useRef(null);
  const formElementsRef = useRef<(HTMLDivElement | HTMLButtonElement | null)[]>(
    []
  );

  useLayoutEffect(() => {
    formRenderedAt.current = Date.now();

    const ctx = gsap.context(() => {
      gsap.set(
        [titleRef.current, descriptionRef.current, ...formElementsRef.current],
        { opacity: 0, y: 30 }
      );

      const mainTl = gsap.timeline({ defaults: { ease: "power3.out" } });

      mainTl.fromTo(
        sectionRef.current,
        { opacity: 0 },
        { opacity: 1, duration: 0.8 }
      );

      mainTl
        .to(titleRef.current, { opacity: 1, y: 0, duration: 1 }, "+=0.2")
        .to(
          descriptionRef.current,
          { opacity: 1, y: 0, duration: 0.8 },
          "-=0.3"
        );

      mainTl.fromTo(
        formRef.current,
        { opacity: 0, scale: 0.9, rotationY: -10 },
        { opacity: 1, scale: 1, rotationY: 0, duration: 1.2, ease: "back.out(1.4)" },
        "-=0.5"
      );

      mainTl.to(
        formElementsRef.current,
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          stagger: { amount: 0.8, from: "start" },
          ease: "power2.out",
        },
        "-=0.3"
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const addToFormRefs = (el: HTMLDivElement | HTMLButtonElement | null) => {
    if (el && !formElementsRef.current.includes(el)) {
      formElementsRef.current.push(el);
    }
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));

    if (errors[name as keyof typeof errors]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }

    if (submitStatus.type) {
      setSubmitStatus({ type: null, message: "" });
    }
  };

  const validateForm = () => {
    const newErrors = { name: "", email: "", phone: "", message: "" };
    let isValid = true;

    if (!formData.name.trim()) {
      newErrors.name = "Name is required";
      isValid = false;
    } else if (formData.name.trim().length < 2) {
      newErrors.name = "Name must be at least 2 characters";
      isValid = false;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email.trim()) {
      newErrors.email = "Email is required";
      isValid = false;
    } else if (!emailRegex.test(formData.email)) {
      newErrors.email = "Please enter a valid email address";
      isValid = false;
    }

    const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
    if (
      formData.phone &&
      !phoneRegex.test(formData.phone.replace(/[\s\-\(\)]/g, ""))
    ) {
      newErrors.phone = "Please enter a valid phone number";
      isValid = false;
    }

    if (!formData.message.trim()) {
      newErrors.message = "Message is required";
      isValid = false;
    } else if (formData.message.trim().length < 10) {
      newErrors.message = "Message must be at least 10 characters";
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Honeypot check — if filled, silently drop the submission (bot detected)
    if (honeypot) {
      setSubmitStatus({
        type: "success",
        message: "Thank you for your message! We'll get back to you soon.",
      });
      return;
    }

    // Timing check — legitimate users take at least 3 seconds to fill a form
    const elapsed = Date.now() - formRenderedAt.current;
    if (elapsed < 3000) {
      setSubmitStatus({
        type: "error",
        message: "Please take a moment to fill in the form completely.",
      });
      return;
    }

    if (!validateForm()) return;

    setIsSubmitting(true);
    setSubmitStatus({ type: null, message: "" });

    try {
      const response = await fetch(`${BASE_URL}/api/message`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...formData,
          source: "cleantech" as const,
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      await response.json();

      setSubmitStatus({
        type: "success",
        message: "Thank you for your message! We'll get back to you soon.",
      });

      setFormData({ name: "", email: "", phone: "", message: "" });
    } catch (error) {
      // Only log in development — never expose errors in production
      if (process.env.NODE_ENV !== "production") {
        console.error("Error submitting form:", error);
      }
      setSubmitStatus({
        type: "error",
        message:
          "Sorry, there was an error sending your message. Please try again later.",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="cleantech-contact-page" ref={sectionRef}>
      {/* Header Section */}
      <div className="cleantech-contact-header">
        <div className="cleantech-contact-intro">
          <div className="cleantech-contact-badge">
            <div className="cleantech-badge-dot"></div>
            Contact Us
          </div>
          <h1>Let's Build a Sustainable Future Together</h1>
          <p>
            Get in touch with our clean technology experts to discuss how we can
            help transform your energy infrastructure and drive your
            sustainability goals forward.
          </p>
        </div>
      </div>

      {/* Main Content Section */}
      <section id="contact" className="cleantech-contact-main-content">
        {/* Left Side - Hero */}
        <div className="cleantech-contact-hero" ref={heroRef}>
          <h2 ref={titleRef}>Get In Touch</h2>
          <p ref={descriptionRef}>
            Ready to embrace sustainable solutions? We're here to help. Reach
            out to us and let's start a conversation about how we can transform
            your energy footprint and drive your green initiatives forward.
          </p>
        </div>

        {/* Right Side - Contact Form */}
        <div className="cleantech-contact-form-wrapper" ref={formRef}>
          {submitStatus.type && (
            <div
              className={`cleantech-submit-status ${submitStatus.type}`}
              ref={addToFormRefs}
            >
              {submitStatus.message}
            </div>
          )}

          <form className="cleantech-contact-form" onSubmit={handleSubmit}>
            {/* Honeypot — hidden from real users, bots fill it in */}
            <div
              aria-hidden="true"
              style={{
                position: "absolute",
                width: "1px",
                height: "1px",
                overflow: "hidden",
                opacity: 0,
                pointerEvents: "none",
                tabIndex: -1,
              } as React.CSSProperties}
            >
              <label htmlFor="website_ct">Website</label>
              <input
                type="text"
                id="website_ct"
                name="website_ct"
                value={honeypot}
                onChange={(e) => setHoneypot(e.target.value)}
                autoComplete="off"
                tabIndex={-1}
              />
            </div>

            <div className="cleantech-form-row">
              <div className="cleantech-form-group" ref={addToFormRefs}>
                <label htmlFor="name">Full Name *</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className={errors.name ? "error" : ""}
                  placeholder="Enter your full name"
                  disabled={isSubmitting}
                />
                {errors.name && (
                  <span className="cleantech-error-message">{errors.name}</span>
                )}
              </div>

              <div className="cleantech-form-group" ref={addToFormRefs}>
                <label htmlFor="email">Email Address *</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className={errors.email ? "error" : ""}
                  placeholder="Enter your email address"
                  disabled={isSubmitting}
                />
                {errors.email && (
                  <span className="cleantech-error-message">
                    {errors.email}
                  </span>
                )}
              </div>
            </div>

            <div className="cleantech-form-group" ref={addToFormRefs}>
              <label htmlFor="phone">Phone Number</label>
              <input
                type="tel"
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                className={errors.phone ? "error" : ""}
                placeholder="Enter your phone number"
                disabled={isSubmitting}
              />
              {errors.phone && (
                <span className="cleantech-error-message">{errors.phone}</span>
              )}
            </div>

            <div className="cleantech-form-group" ref={addToFormRefs}>
              <label htmlFor="message">Your Message *</label>
              <textarea
                id="message"
                name="message"
                value={formData.message}
                onChange={handleChange}
                className={errors.message ? "error" : ""}
                placeholder="Tell us about your clean energy project or inquiry..."
                rows={5}
                disabled={isSubmitting}
              />
              {errors.message && (
                <span className="cleantech-error-message">
                  {errors.message}
                </span>
              )}
            </div>

            <button
              type="submit"
              className="cleantech-submit-button"
              ref={addToFormRefs}
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <div className="cleantech-spinner"></div>
                  Sending...
                </>
              ) : (
                "Send Message"
              )}
            </button>
          </form>
        </div>
      </section>
    </div>
  );
}
